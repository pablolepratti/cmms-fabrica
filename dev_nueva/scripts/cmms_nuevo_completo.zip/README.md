
# 🧠 CMMS Fábrica – Sistema de Mantenimiento Centrado en el Activo Técnico

Este sistema organiza todas las tareas de mantenimiento de una fábrica real, con foco en cada activo técnico.

## 📦 Estructura

- `app.py` – Panel principal de navegación
- `modulos/` – Módulos funcionales:
  - `app_activos.py` – Visualización de activos
  - `app_mantenimiento.py` – Tareas preventivas
  - `app_tareas.py` – Correctivas
  - `app_tareas_tecnicas.py` – Técnicas
  - `app_calibracion.py` – Calibraciones (Calidad)
  - `app_observaciones.py` – Observaciones de planta
  - `app_reportes.py` – Exportación y resúmenes

## 💾 Requisitos

```bash
pip install -r requirements.txt
```

## 🚀 Cómo usar

```bash
streamlit run app.py
```

## 🛠 Estructura de MongoDB

Colección principal: `cmms.activos_tecnicos`  
Cada documento representa un activo con sus tareas, historial, observaciones y calibraciones.

## 🧪 Migración original

Los datos fueron migrados desde una base Mongo previa, estructurados con el script `migrar_cmms.py` y `subir_a_mongo.py`.

---

Este CMMS es funcional, simple y puede ser extendido o conectado a sistemas más complejos como MIA (Mantenimiento Inteligente Asistido).
