
import os
import json
from bson import decode_all

# Ruta base del backup (ajustar si lo descomprimiste en otro lugar)
BASE_PATH = "backup_cmms_fabrica/backup_cmms_fabrica/cmms"

# Función para cargar documentos desde un archivo BSON
def cargar_bson(nombre):
    ruta = os.path.join(BASE_PATH, f"{nombre}.bson")
    with open(ruta, "rb") as f:
        data = f.read()
    return decode_all(data)

# Cargar activos técnicos desde 'maquinas'
activos_raw = cargar_bson("maquinas")
activos = {}

for doc in activos_raw:
    _id = doc.get("_id")
    activos[_id] = {
        "_id": _id,
        "nombre": doc.get("nombre", ""),
        "sector": doc.get("sector", "Sin sector definido"),
        "tareas_preventivas": [],
        "tareas_correctivas": [],
        "tareas_tecnicas": [],
        "calibraciones": [],
        "observaciones": [],
        "historial": [],
        "repuestos_usados": [],
        "reportes": []
    }

# Función para agrupar datos por id_activo
def agrupar_en_activos(nombre_coleccion, campo_destino, id_campo="id_activo"):
    docs = cargar_bson(nombre_coleccion)
    for doc in docs:
        activo_id = doc.get(id_campo)
        if activo_id in activos:
            activos[activo_id][campo_destino].append(doc)
        else:
            # Crear nuevo activo si es instrumento de calidad o no registrado
            activos[activo_id] = {
                "_id": activo_id,
                "nombre": doc.get("nombre", "Instrumento sin nombre"),
                "sector": "Calidad",
                "tareas_preventivas": [],
                "tareas_correctivas": [],
                "tareas_tecnicas": [],
                "calibraciones": [],
                "observaciones": [],
                "historial": [],
                "repuestos_usados": [],
                "reportes": []
            }
            activos[activo_id][campo_destino].append(doc)

# Asociar colecciones a sus campos destino
agrupar_en_activos("tareas", "tareas_correctivas")
agrupar_en_activos("mantenimientos", "tareas_preventivas")
agrupar_en_activos("tareas_tecnicas", "tareas_tecnicas")
agrupar_en_activos("calibracion_instrumentos", "calibraciones")
agrupar_en_activos("observaciones", "observaciones")
agrupar_en_activos("historial", "historial")
agrupar_en_activos("inventario", "repuestos_usados")

# Guardar resultado como JSON único
with open("activos_unificados.json", "w", encoding="utf-8") as f:
    json.dump(list(activos.values()), f, indent=2, ensure_ascii=False)

print(f"Exportación completa: {len(activos)} activos exportados a 'activos_unificados.json'")
